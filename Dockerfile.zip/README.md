# Backend System Design

## Project Setup

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd backend-system-design
